# Parking Management System

Parking management system to manage parking at parking lots.
Designed and built in < 24 hours.