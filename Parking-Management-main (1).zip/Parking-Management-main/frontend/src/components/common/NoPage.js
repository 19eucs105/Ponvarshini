import React from 'react'

const NoPage = () => {
  return (
    <div>

        <p>Page not found.</p>

    </div>
  )
}

export default NoPage